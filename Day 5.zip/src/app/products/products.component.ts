import { Component, OnInit } from '@angular/core';
import {CrudService} from '../crud.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  constructor(private crud:CrudService,private cs:CookieService) { }
   public productdata;
  ngOnInit() {

  	this.crud.selectData("products").subscribe(
         	(results)=>{
         		// console.log(results);
         		this.productdata=results;
         	}
         	);
  }

  addToCart(id,e)
  {
    e.preventDefault();
    //console.log(id)
    //console.log(e)

    var result=this.cs.get("cart_id");
    if(result.length>0)
    {
      var arr=result.split(",");
       
      if(arr.indexOf(id.toString())==-1)
      {
        var newpro=result+","+id
        this.cs.set("cart_id",newpro)
        alert("Cart Updated");
      } 
      else
      {
        alert("Product exist in cart");
      }
    }
    else
    {
      this.cs.set("cart_id",id);
      alert("Product Added");
    }
   }
  }


