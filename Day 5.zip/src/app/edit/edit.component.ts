import { Component, OnInit } from '@angular/core';
import {CrudService} from '../crud.service';
import {ActivatedRoute,Router} from'@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  constructor(private actrouter:ActivatedRoute, private routerobj:Router ,
  	private crud:CrudService) { }
    cat:string;
  ngOnInit() {

     var catid=Number(this.actrouter.snapshot.params.xyz);
  	 	//console.log(catid);
  	 this.crud.selectData_filter("category",catid).subscribe(
        	(results)=>{
         		
         		this.cat=results.name;
        	}
        	);

  }

  edit_category(record)
  {
  	 var catid=Number(this.actrouter.snapshot.params.xyz);

  	 this.crud.updateData("category",catid,{name:record}).subscribe(
      (response)=>{

          console.log(response);
         }
  	 	);
    }
    

  

}
