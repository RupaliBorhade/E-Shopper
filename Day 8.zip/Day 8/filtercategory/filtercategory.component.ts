import { Component, OnInit } from '@angular/core';
import {CrudService} from '../crud.service';
import {ActivatedRoute,Router} from'@angular/router';

@Component({
  selector: 'app-filtercategory',
  templateUrl: './filtercategory.component.html',
  styleUrls: ['./filtercategory.component.css']
})
export class FiltercategoryComponent implements OnInit {

  constructor(private actrouter:ActivatedRoute, private routerobj:Router ,
  	private crud:CrudService) { }
     filterdata=[]

  ngOnInit() {
  	
  	var catid=Number(this.actrouter.snapshot.params.xyz);

    this.crud.selectData("products").subscribe(
         	(results)=>{
         		// console.log(results[answer]);

         		for(var answer in results)
         		{

         		if(catid==results[answer].catid)
         		{	
         		this.filterdata.push(results[answer]);
         	    }  
         	    }      	
            }
         	);
  }

}
