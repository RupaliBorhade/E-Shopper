import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,FormBuilder,Validators,NgForm} from '@angular/forms';

@Component({
  selector: 'app-angform-validation',
  templateUrl: './angform-validation.component.html',
  styleUrls: ['./angform-validation.component.css']
})
export class AngformValidationComponent implements OnInit {

   signupForm:FormGroup;
   /*FirstName:string="";  
   LastName:string="";  
   Email:string="";  
   Password:string="";*/
 
  constructor(private frmbuilder:FormBuilder) { 
    
   /* this.signupForm=frmbuilder.group(
    {
    	username:new FormControl(),
    	mobile:new FormControl(),
    	email:new FormControl(),
    	pwd:new FormControl(),
    }) */ 
 
  }

  ngOnInit() {
   this.signupForm=this.frmbuilder.group(
    {
      username:['',Validators.required],
      mobile:['',Validators.required],
      email:['',Validators.required],
      pwd:['',Validators.required],
    }
    )

  }
 
   PostData(signupForm:NgForm)
   {
    console.log(signupForm.controls);
   }
  
}
