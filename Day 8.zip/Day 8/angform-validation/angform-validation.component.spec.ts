import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AngformValidationComponent } from './angform-validation.component';

describe('AngformValidationComponent', () => {
  let component: AngformValidationComponent;
  let fixture: ComponentFixture<AngformValidationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AngformValidationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AngformValidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
