import { Component, OnInit } from '@angular/core';
import {CrudService} from '../crud.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  errrmsg:string="";

  constructor(private crud:CrudService) { }

  ngOnInit() {
  }

  onSubmit(rec)
  {
    //console.log(rec)
  	//console.log(localStorage);

  	if(localStorage && typeof localStorage=="object")
  	{
  		var name=localStorage.getItem("Username");   //Username come from localstorage from register data stared.
  		var pass=localStorage.getItem("Password");

  		if(name==rec.uname && pass==rec.pass) // check localstaorage with user inputed data from login.html
      {
        this.errrmsg="Ok";
      }
  	
    	else
    	{
       this.errrmsg="Failed To Login";
    	}
   }
  }

}
