import { Component, OnInit } from '@angular/core';
import {CrudService} from '../crud.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  constructor(private crud:CrudService) { }
   public productdata;
  ngOnInit() {

  	this.crud.selectData("products").subscribe(
         	(results)=>{
         		// console.log(results);
         		this.productdata=results;
         	}
         	);
  }

}
