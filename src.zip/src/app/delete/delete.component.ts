import { Component, OnInit } from '@angular/core';
import {CrudService} from '../crud.service';
import {ActivatedRoute,Router} from'@angular/router';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  constructor(private actrouter:ActivatedRoute, private routerobj:Router ,
  	private crud:CrudService)
  	 { }

  ngOnInit() {
  	 var catid=Number(this.actrouter.snapshot.params.xyz);
  	 	//console.log(catid);
  	 this.crud.deleteData("category",catid).subscribe(
        	(results)=>{
         		
         		this.routerobj.navigate(["/category"]);
        	}
        	); 
  }

}
