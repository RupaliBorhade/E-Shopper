import { Component, OnInit } from '@angular/core';
import {CrudService} from '../crud.service';

@Component({
  selector: 'app-addcategory',
  templateUrl: './addcategory.component.html',
  styleUrls: ['./addcategory.component.css']
})
export class AddcategoryComponent implements OnInit {

  constructor(private crud:CrudService) { }
   public errmsg;
   public categorydata;
  ngOnInit() {

  	this.showdata();

  }
showdata()
{
	this.crud.selectData("category").subscribe(
         	(results)=>{
         		// console.log(results);
         		this.categorydata=results;
         	}
         	);
}

  add_category(catRecord)
  {

  	if(catRecord.length==0)
  	{
  		this.errmsg="Please enter category";
  	}
  	else{
  	this.crud.insertData("category",{name:catRecord}).subscribe(
         	(results)=>{
         		// console.log(results);
         		this.errmsg="Category added";
         	}
         	);
  }
}

deletecat(id)
{
	this.crud.deleteData("category",id).subscribe(
         	(results)=>{
         		// console.log(results);
         		this.showdata();
         	}
         	);
}

}
