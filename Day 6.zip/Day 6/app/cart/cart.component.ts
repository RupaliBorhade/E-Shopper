import { Component, OnInit } from '@angular/core';
import {CrudService} from '../crud.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor(private crud:CrudService,private cs:CookieService) { }
  public productdata=[];
  public cartRecord:string
  ngOnInit() {

  	if(this.cs.get("cart_id"))
  	{
        var res=this.cs.get("cart_id").split(",")
  
  	this.crud.selectData("products").subscribe(
         	(results)=>{
         		// console.log(results);
         		for(var ans in results)
         		{
 					if(res.indexOf(results[ans].id.toString())>=0)
 					{
 						this.productdata.push(results[ans])
 					}
         		}
         	})
     }

	   else
	   {
	   	 this.cartRecord="No data found";

	   }

  }

  deleteToCart(id,e)
  {
    if(confirm("You want to delete from cart ?"))
    {
    e.preventDefault();
    //console.log(e)
    //console.log(id)

    var cookidata=this.cs.get("cart_id").split(",")
    //console.log(cookidata) fetch cart data and spilt using ,

    var pos=cookidata.indexOf(id.toString());
     //console.log(pos) find position of id which needs to deleted 

    cookidata.splice(pos,1)
     //console.log(cookidata) 1 for deleting that single element. Splice is javascript method for deletion.

    var newval=cookidata.join(",");

    this.cs.set("cart_id",newval)

    e.target.parentNode.parentNode.parentNode.parentNode.style.display="none";
    //parentNode is property to fetch parent of parent of parent of target is means div of that id will fetch and hide
  }
  else
  {
    return false;
  }

   }
}
