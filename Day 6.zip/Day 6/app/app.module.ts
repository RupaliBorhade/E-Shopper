import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { HttpModule} from '@angular/http';
import {RouterModule, Routes} from '@angular/router';
import {CrudService} from './crud.service';
import { CookieService } from 'ngx-cookie-service';

import { AppComponent } from './app.component';
import { CategoryComponent } from './category/category.component';
import { BrandsComponent } from './brands/brands.component';
import { HeaderComponent } from './header/header.component';
import { SliderComponent } from './slider/slider.component';
import { ProductsComponent } from './products/products.component';
import { FooterComponent } from './footer/footer.component';
import { AddcategoryComponent } from './addcategory/addcategory.component';
import { AddbrandComponent } from './addbrand/addbrand.component';
import { DeleteComponent } from './delete/delete.component';
import { EditComponent } from './edit/edit.component';
import { FiltercategoryComponent } from './filtercategory/filtercategory.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { CartComponent } from './cart/cart.component';

const appRoutes: Routes=[

   {path:'', component:ProductsComponent},
   {path:'category', component:AddcategoryComponent},
   {path:'brand' , component:AddbrandComponent},
   {path:'deletecat/:xyz' , component:DeleteComponent},
   {path:'editcat/:xyz' , component:EditComponent},
   {path:'filter_category/:xyz' , component:FiltercategoryComponent},
   {path:'cart' , component:CartComponent},
   {path:'register' , component:RegisterComponent}
   
];


@NgModule({
  declarations: [
    AppComponent,
    CategoryComponent,
    BrandsComponent,
    HeaderComponent,
    SliderComponent,
    ProductsComponent,
    FooterComponent,
    AddcategoryComponent,
    AddbrandComponent,
    DeleteComponent,
    EditComponent,
    FiltercategoryComponent,
    LoginComponent,
    RegisterComponent,
    CartComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: true } // <-- debugging purposes only
    ),
    HttpModule,
    FormsModule
  ],
  providers: [CrudService,CookieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
