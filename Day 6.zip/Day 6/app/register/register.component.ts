import { Component, OnInit } from '@angular/core';
import {CrudService} from '../crud.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private crud:CrudService) { }

  ngOnInit() {

    
  }

 onSubmit(record)
 {
 	 //console.log(record)

   if(localStorage && typeof localStorage=="object")
   {
   	 //console.log(localStorage) to chekc localstorage is present or not
     
     localStorage.setItem("Username",record.username );
     localStorage.setItem("MobileNo",record.mobile );
     localStorage.setItem("EmailId",record.email );
     localStorage.setItem("Password",record.pwd );

     //sms
     //Textlocal.com for random msg sending. Register verify and use for free 10 msg
	// https://control.textlocal.in/docs
	//http://control.textlocal.in/docs/api/code/post/

	//id - mail my

	//password : Rupali@30

	 var msg="Welcome to Angular JS, pass:"+record. pwd;

	 var str="http://api.textlocal.in/send/?username=rupaliborhade30@gmail.com&hash=f4a80b39e9d6d4c26ab3c876ceb844d6fbf11c185b5df44193a71f262fea927f&message="+msg+"&sender=TXTLCL&numbers=91"+record.mobile+"&test=0";
      
    this.crud.selectData_msg(str).subscribe(
         (results)=>{
         	console.log(results);
         }
    	)


	// console.log(str)
	 //by using console.log(str)your full url displays
  }      	

}
